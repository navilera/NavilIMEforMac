./uninstall.sh

cp -r ./NavilIME.app ~/Library/Input\ Methods

ls ~/Library/Input\ Methods
