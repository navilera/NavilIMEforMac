echo "rm -fr ~/Library/Input\ Methods/NavilIME.app"
rm -fr ~/Library/Input\ Methods/NavilIME.app
